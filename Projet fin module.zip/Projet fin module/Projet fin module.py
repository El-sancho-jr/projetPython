import pickle
import os
import sys
tabPlat = []
tabCommande = []

class Commande :
    def __init__(self,numRecu,nomPro,commande) :
        self.numRecu = numRecu
        self.nomPro = nomPro
        self.commande = commande
        
# FONCTION POUR RECHERCHER LES DOUBLANT D'UN PLAT

    def recherche(numRecu) :
        for i in range(len(tabCommande)) :
            if tabCommande[i].numRecu == numRecu :
                return i
        return -1


    
# FONCTION POUR AJOUTER UN COMMANDE
    def faireCommande() :
        Commande.afficherCommande()
        numRecu = input ("Saisir le numero du reçu : ")
        nomPro = input ("Saisir le nom du client : ")
        commande = input ("Saisir le nom du plat: ")
        tabCommande.append(Commande(numRecu,nomPro,commande))
        print("Commande ajouter avec succes")
        Commande.majTableauAFichierCommande()
        input ("Appuyer sur la touche M pour revenir au menu : ")


# FONCTION POUR REMPLIR LE TABLEAU COMMANDE GRACE AU FICHIER
    def FichierATableauCommande () :
        tabCommande.clear()
        try :
            fichier = open ("Gestion des commande.txt","rb")
            chargement = pickle.load(fichier)
            for i in range (len (chargement)) :
                tabCommande.append(chargement[i])
            fichier.close()
        except EOFError :
            print("Fichier vide")
        except FileNotFoundError :
            print("Fichier introuvable")
            fichier = open ("Gestion des commande.txt","wb")
        except IOError :
            print("Erreur d'entree et de sortis")


# FONCTION POUR REMPLIR LE FICHIER GRACE AU TABLEAU COMMANDE

    def majTableauAFichierCommande() :
        fichier = open ("Gestion des commande.txt", "wb")
        pickle.dump(tabCommande,fichier)
        fichier.close()

# FONCTION POUR SUPPRIMER UN COMMANDE

    def supprimerCommande() :
        Commande.afficherCommande()
        numRecu = input ("Saisir le numero du commande a supprimer : ")
        if Commande.recherche(numRecu) != -1 :
            del tabCommande[Commande.recherche(numRecu)]
            print("Commande supprimer avec succes")
        else :
            print ("Plat introuvable")
        Commande.majTableauAFichierCommande()
        input ("Appuyer sur la touche M pour revenir au menu : ")


# FONCTION POUR AFFICHER TOUS LES COMMANDES

    def afficherCommande () :
        for i in range (len (tabCommande)) :
            print("=============================================================")
            print("N° reçu : ",tabCommande[i].numRecu)
            print("Nom Commandeur : ",tabCommande[i].nomPro)
            print("Commande : ",tabCommande[i].commande)
            print("=============================================================")
            Commande.FichierATableauCommande()

# FONCTION POUR AFFICHER TOUS LES PLATS

    def afficherPlat () :
        for i in range (len (tabPlat)) :
            print("=============================================================")
            print("Nom : ",tabPlat[i].nom)
            print("Description : ",tabPlat[i].description)
            print("Prix : ",tabPlat[i].prix)
            print("=============================================================")
            Plat.FichierATableauPlat()
        input ("Appuyer sur la touche M pour revenir au menu : ")


class Plat :
    def __init__(self,numRecu,nom,description,prix):
        self.numRecu = numRecu
        self.nom = nom
        self.description = description
        self.prix = prix
    
# FONCTION POUR RECHERCHER LES DOUBLANT D'UN PLAT

    def recherche(nom) :
        for i in range(len(tabPlat)) :
            if tabPlat[i].numRecu == nom :
                return i
        return -1

# FONCTION POUR AJOUTER UN PLAT

    def ajouterPlat() :
        Plat.afficherPlat()
        numRecu = input ("Saisir le n° du plat à ajouter : ")
        while Plat.recherche(numRecu)!= -1 :
            print ("N° du plat existant, Verifier sur la liste des plat et ")
            numRecu = input ("Saisir le N° du plat : ")
        nom = input ("Saisir le nom du plat : ")
        while Plat.recherche(nom)!= -1 :
            nom = input ("Nom du plat existant, Saisir un autre plat : ")
        description = input ("Saisir la description du plat : ")
        prix = input ("Saisir le prix du plat : ")
        tabPlat.append(Plat(numRecu,nom,description,prix))
        print("Plat ajouter avec succes")
        Plat.majTableauAFichierPlat()
        input ("Appuyer sur la touche M pour revenir au menu : ")


# FONCTION POUR SUPPRIMER UN PLAT

    def supprimerPlat() :
        numRecu = input ("Saisir le N° du plat a supprimer : ")
        if Plat.recherche(numRecu) != -1 :
            del tabPlat[Plat.recherche(numRecu)]
            print("plat supprimer avec succes")
        else :
            print ("Plat introuvable")
        Plat.majTableauAFichierPlat()
        input ("Appuyer sur la touche M pour revenir au menu : ")

# FONCTION POUR MODIFIER UN PLAT

    def modifierPlat() :
        Plat.afficherPlat()
        numRecu = input ("Saisir le N° du plat a modifier : ")
        nom = input ("Saisir le nouveau nom du plat :")
        while Plat.recherche(nom) != -1:
            nom = input ("N° du plat existant, Saisir un autre N° : ")
        description = input ("Saisir la nouvelle description : ")
        prix = input ("Saisir le nouveau prix : ")
        upload = Plat (numRecu,nom,description,prix)
        tabPlat[Plat.recherche(numRecu)] = upload
        Plat.majTableauAFichierPlat()
        print ("Plat modifier avec succes")
        input ("Appuyer sur la touche M pour revenir au menu : ")

# FONCTION POUR REMPLIR LE TABLEAU PLAT GRACE AU FICHIER

    def FichierATableauPlat () :
        tabPlat.clear()
        try :
            fichier = open ("Gestion des Plat.txt","rb")
            chargement = pickle.load(fichier)
            for i in range (len (chargement)) :
                tabPlat.append(chargement[i])
            fichier.close()
        except EOFError :
            print("Fichier vide")
        except FileNotFoundError :
            print("Fichier introuvable")
            fichier = open ("Gestion des Plat.txt","wb")
        except IOError :
            print("Erreur d'entree et de sortis")


# FONCTION POUR REMPLIR LE FICHIER GRACE AU TABLEAU PLAT

    def majTableauAFichierPlat() :
        fichier = open ("Gestion des Plat.txt", "wb")
        pickle.dump(tabPlat,fichier)
        fichier.close()

# FONCTION POUR AFFICHER TOUS LES PLATS

    def afficherPlat () :
        for i in range (len (tabPlat)) :
            print("=============================================================")
            print("N° plat : ",tabPlat[i].numRecu)
            print("Nom : ",tabPlat[i].nom)
            print("Description : ",tabPlat[i].description)
            print("Prix : ",tabPlat[i].prix)
            print("=============================================================")
            Plat.FichierATableauPlat()

# FONCTION POUR QUITTER LE PROGRAMME

    def quitter () :
        print ("programme fermer, Veuiller relancer le programme pour\n",
               "effectue a nouveau les taches")
        sys.exit()
        

# FONCTION DU MENU POUR L'UTILISATEUR

    def menuAd () :
        while True :
            os.system('cls')
            print("=============================================================")
            print("==================== GESTION DES PLATS ======================")
            print("=============================================================")
            print("1 - Ajouter un plat")
            print("2 - Modifier un plat")
            print("3 - Supprimer un plat")
            print("4 - Afficher les plat")
            print("5 - Retour")
            
            menuA = {
                1 : Plat.ajouterPlat,
                2 : Plat.modifierPlat,
                3 : Plat.supprimerPlat,
                4 : Plat.afficherPlat,
                5 : Plat.retour,
            }
            choix = int(input ("Entrer votre choix : "))
            menuA[choix]()


# FONCTION DU MENU POUR L'ADMINISTRATEUR

    def menuUti () :
        while True :
            os.system('cls')
            print("=============================================================")
            print("================= GESTION DES COMMANDES =====================")
            print("=============================================================")
            print("1 - Afficher les plat")
            print("2 - Faire une commande")
            print("3 - Afficher les commande")
            print("4 - Supprimer commande")
            print("5 - Retour")

            menuU = {
                
                1 : Commande.afficherPlat,
                2 : Commande.faireCommande,
                3 : Commande.afficherCommande,
                4 : Commande.supprimerCommande,
                5 : Plat.retour,

            }
            choix = int(input ("Entrer votre choix : "))
            menuU[choix]()


# FONCTION DU MENU PRINCIPALE

    def menu () :
        while True :
            os.system('cls')
            print("=============================================================")
            print("==================== MENU PRINCIPALE ========================")
            print("=============================================================")
            print("1 - Gestion de l'administrateur")
            print("2 - Gestion des commandes")
            print("3 - Quitter")

            menuP = {
                1 : Plat.menuAd,
                2 : Plat.menuUti,
                3 : Plat.quitter

            }
            choix = int(input ("Entrer votre choix : "))
            menuP[choix]()


# FONCTION POUR RETOURNER AU MENU PRINCIPALE

    def retour () :
        Plat.menu ()
        input ("Appuyer sur une touche pour continue : ")


Commande.FichierATableauCommande()
Plat.FichierATableauPlat()
Plat.menu()

