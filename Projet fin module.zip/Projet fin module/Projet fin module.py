import pickle
import os
import sys
tableau_Plat = []
tableau_Commande = []

class Commande :
    def __init__(self,numero_Recu,nom_Proprietaire,commande) :
        self.numero_Recu = numero_Recu
        self.nom_Proprietaire = nom_Proprietaire
        self.commande = commande
        
# FONCTION POUR RECHERCHER LES DOUBLANT D'UN Plat_Classe

    def recherche(numero_Recu) :
        for i in range(len(tableau_Commande)) :
            if tableau_Commande[i].numero_Recu == numero_Recu :
                return i
        return -1


    
# FONCTION POUR AJOUTER UN COMMANDE
    def ajout_Commande() :
        Commande.Affichage_Commande()
        numero_Recu = input ("Saisir le numero du reçu : ")
        nom_Proprietaire = input ("Saisir le nom du client : ")
        commande = input ("Saisir le nom du Plat: ")
        tableau_Commande.append(Commande(numero_Recu,nom_Proprietaire,commande))
        print("Commande ajouter avec succes")
        Commande.majTableauAFichierCommande()
        input ("Appuyer sur la touche M pour revenir au menu Principale : ")


# FONCTION POUR REMPLIR LE TABLEAU COMMANDE GRACE AU FICHIER
    def FichierATableauCommande () :
        tableau_Commande.clear()
        try :
            fichier = open ("Gestion des commande.txt","rb")
            chargement = pickle.load(fichier)
            for i in range (len (chargement)) :
                tableau_Commande.append(chargement[i])
            fichier.close()
        except EOFError :
            print("Fichier vide")
        except FileNotFoundError :
            print("Fichier introuvable")
            fichier = open ("Gestion des commande.txt","wb")
        except IOError :
            print("Erreur d'entree et de sortis")


# FONCTION POUR REMPLIR LE FICHIER GRACE AU TABLEAU COMMANDE

    def majTableauAFichierCommande() :
        fichier = open ("Gestion des commande.txt", "wb")
        pickle.dump(tableau_Commande,fichier)
        fichier.close()

# FONCTION POUR SUPPRIMER UN COMMANDE

    def suppression_Commande() :
        Commande.Affichage_Commande()
        numero_Recu = input ("Saisir le numero du commande a supprimer : ")
        if Commande.recherche(numero_Recu) != -1 :
            del tableau_Commande[Commande.recherche(numero_Recu)]
            print("Commande supprimer avec succes")
        else :
            print ("Plat_Classe introuvable")
        Commande.majTableauAFichierCommande()
        input ("Appuyer sur la touche M pour revenir au menu Principale : ")


# FONCTION POUR AFFICHER TOUS LES COMMANDES

    def Affichage_Commande () :
        for i in range (len (tableau_Commande)) :
            print("=============================================================")
            print("N° reçu : ",tableau_Commande[i].numero_Recu)
            print("Nom Commandeur : ",tableau_Commande[i].nom_Proprietaire)
            print("Commande : ",tableau_Commande[i].commande)
            print("=============================================================")
            Commande.FichierATableauCommande()

# FONCTION POUR AFFICHER TOUS LES Plat

    def affichage_Plat () :
        for i in range (len (tableau_Plat)) :
            print("=============================================================")
            print("Nom : ",tableau_Plat[i].nom_Plat)
            print("Description : ",tableau_Plat[i].description)
            print("Prix : ",tableau_Plat[i].prix)
            print("=============================================================")
            Plat_Classe.FichierATableauPlat()
        input ("Appuyer sur la touche M pour revenir au menu Principale : ")


class Plat_Classe :
    def __init__(self,numero_Plat,nom_Plat,description,prix):
        self.numero_Plat = numero_Plat
        self.nom_Plat = nom_Plat
        self.description = description
        self.prix = prix
    
# FONCTION POUR RECHERCHER LES DOUBLANT D'UN Plat_Classe

    def recherche(numero_Plat) :
        for i in range(len(tableau_Plat)) :
            if tableau_Plat[i].numero_Plat == numero_Plat :
                return i
        return -1

# FONCTION POUR AJOUTER UN Plat

    def ajout_Plat() :
        Plat_Classe.affichage_Plat()
        numero_Plat = input ("Saisir le n° du Plat à ajouter : ")
        while Plat_Classe.recherche(numero_Plat)!= -1 :
            print ("N° du Plat existant, Verifier sur la liste des Plat et ")
            numero_Plat = input ("Saisir le N° du Plat : ")
        nom_Plat = input ("Saisir le nom du Plat : ")
        while Plat_Classe.recherche(nom_Plat)!= -1 :
            nom_Plat = input ("nom du Plat existant, Saisir un autre Plat : ")
        description = input ("Saisir la description du Plat : ")
        prix = input ("Saisir le prix du Plat : ")
        tableau_Plat.append(Plat_Classe(numero_Plat,nom_Plat,description,prix))
        print("Plat ajouter avec succes")
        Plat_Classe.majTableauAFichierPlat()
        input ("Appuyer sur la touche M pour revenir au menu Principale : ")


# FONCTION POUR SUPPRIMER UN Plat

    def suppression_Plat() :
        numero_Plat = input ("Saisir le N° du Plat a supprimer : ")
        if Plat_Classe.recherche(numero_Plat) != -1 :
            del tableau_Plat[Plat_Classe.recherche(numero_Plat)]
            print("Plat supprimer avec succes")
        else :
            print ("Plat introuvable")
        Plat_Classe.majTableauAFichierPlat()
        input ("Appuyer sur la touche M pour revenir au menu Principale : ")

# FONCTION POUR MODIFIER UN Plat

    def Modification_Plat() :
        Plat_Classe.affichage_Plat()
        numero_Plat = input ("Saisir le N° du Plat a modifier : ")
        nom_Plat = input ("Saisir le nouveau nom du Plat :")
        while Plat_Classe.recherche(nom_Plat) != -1:
            nom_Plat = input ("N° du Plat existant, Saisir un autre N° : ")
        description = input ("Saisir la nouvelle description : ")
        prix = input ("Saisir le nouveau prix : ")
        upload = Plat_Classe (numero_Plat,nom_Plat,description,prix)
        tableau_Plat[Plat_Classe.recherche(numero_Plat)] = upload
        Plat_Classe.majTableauAFichierPlat()
        print ("Plat modifier avec succes")
        input ("Appuyer sur la touche M pour revenir au menu Principale : ")

# FONCTION POUR REMPLIR LE TABLEAU Plat_Classe GRACE AU FICHIER

    def FichierATableauPlat () :
        tableau_Plat.clear()
        try :
            fichier = open ("Gestion des Plat.txt","rb")
            chargement = pickle.load(fichier)
            for i in range (len (chargement)) :
                tableau_Plat.append(chargement[i])
            fichier.close()
        except EOFError :
            print("Fichier vide")
        except FileNotFoundError :
            print("Fichier introuvable")
            fichier = open ("Gestion des Plat.txt","wb")
        except IOError :
            print("Erreur d'entree et de sortis")


# FONCTION POUR REMPLIR LE FICHIER GRACE AU TABLEAU Plat_Classe

    def majTableauAFichierPlat() :
        fichier = open ("Gestion des Plat.txt", "wb")
        pickle.dump(tableau_Plat,fichier)
        fichier.close()

# FONCTION POUR AFFICHER TOUS LES Plat_ClasseS

    def affichage_Plat () :
        for i in range (len (tableau_Plat)) :
            print("=============================================================")
            print("N° Plat_Classe : ",tableau_Plat[i].numero_Plat)
            print("nom_Plat_Classe : ",tableau_Plat[i].nom_Plat)
            print("Description : ",tableau_Plat[i].description)
            print("Prix : ",tableau_Plat[i].prix)
            print("=============================================================")
            Plat_Classe.FichierATableauPlat()

# FONCTION POUR QUITTER LE PROGRAMME

    def quitter () :
        print ("programme fermer, Veuiller relancer le programme pour\n",
               "effectue a nouveau les taches")
        sys.exit()
        

# FONCTION DU menu_Principale POUR L'UTILISATEUR

    def menu_Plat () :
        while True :
            os.system('cls')
            print("=============================================================")
            print("==================== GESTION DES Plat_ClasseS ======================")
            print("=============================================================")
            print("1 - Ajouter un Plat")
            print("2 - Modifier un Plat")
            print("3 - Supprimer un Plat")
            print("4 - Afficher les Plat")
            print("5 - Retour")
            
            menu_Plat = {
                1 : Plat_Classe.ajout_Plat,
                2 : Plat_Classe.Modification_Plat,
                3 : Plat_Classe.suppression_Plat,
                4 : Plat_Classe.affichage_Plat,
                5 : Plat_Classe.retour,
            }
            choix = int(input ("Entrer votre choix : "))
            menu_Plat[choix]()


# FONCTION DU menu_Principale POUR L'ADMINISTRATEUR

    def menu_Commande () :
        while True :
            os.system('cls')
            print("=============================================================")
            print("================= GESTION DES COMMANDES =====================")
            print("=============================================================")
            print("1 - Afficher les Plat")
            print("2 - Faire une commande")
            print("3 - Afficher les commande")
            print("4 - Supprimer commande")
            print("5 - Retour")

            menu_commande = {
                
                1 : Commande.affichage_Plat,
                2 : Commande.ajout_Commande,
                3 : Commande.Affichage_Commande,
                4 : Commande.suppression_Commande,
                5 : Plat_Classe.retour,

            }
            choix = int(input ("Entrer votre choix : "))
            menu_commande[choix]()


# FONCTION DU menu_Principale PRINCIPALE

    def menu_Principale () :
        while True :
            os.system('cls')
            print("=============================================================")
            print("==================== MENU PRINCIPALE ========================")
            print("=============================================================")
            print("1 - Gestion de l'administrateur")
            print("2 - Gestion des commandes")
            print("3 - Quitter")

            menu_Principale = {
                1 : Plat_Classe.menu_Plat,
                2 : Plat_Classe.menu_Commande,
                3 : Plat_Classe.quitter

            }
            choix = int(input ("Entrer votre choix : "))
            menu_Principale[choix]()


# FONCTION POUR RETOURNER AU menu_Principale PRINCIPALE

    def retour () :
        Plat_Classe.menu_Principale ()
        input ("Appuyer sur une touche pour continue : ")


Commande.FichierATableauCommande()
Plat_Classe.FichierATableauPlat()
Plat_Classe.menu_Principale()

